/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library com.metalsxp.vcha.uiextlib.
 */
sap.ui.define([
	"sap/ui/core/library"
], function () {
	"use strict";

	// delegate further initialization of this library to the Core
	// Hint: sap.ui.getCore() must still be used to support preload with sync bootstrap!
	sap.ui.getCore().initLibrary({
		name: "com.metalsxp.vcha.uiextlib",
		version: "1.0.0",
		dependencies: [ // keep in sync with the ui5.yaml and .library files
			"sap.ui.core"
		],
		interfaces: [],
		controls: [
			"com.metalsxp.vcha.uiextlib.SemanticObjectController",
		],
		elements: [],
		noLibraryCSS: true // if no CSS is provided, you can disable the library.css load here
	});

	/**
	 * Helpers for AVC UI extension
	 *
	 * @namespace
	 * @name com.metalsxp.vcha.uiextlib
	 * @author metalsXP
	 * @version 1.0.0
	 * @public
	 */
	var thisLib = com.metalsxp.vcha.uiextlib;

	thisLib.openLink = function (sUrl, bAsNewTab) {
		if (window.name.indexOf("itshtmlvwrfn") >= 0) {
			if (!bAsNewTab) {
				document.location.href = sUrl;
			} else {
				window.top.open(sUrl, bAsNewTab ? "_blank" : false);
			}
		} else {
			sap.m.URLHelper.redirect(sUrl, bAsNewTab);
		}
	};

	return thisLib;

});
