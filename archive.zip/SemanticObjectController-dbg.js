sap.ui.define(["./library", "sap/ui/comp/navpopover/SemanticObjectController", "sap/base/Log"], function (library, SemanticObjectController, Log) {
    "use strict";

    return SemanticObjectController.extend("com.metalsxp.vcha.uiextlib.SemanticObjectController", {
        metadata: {
            properties: {
                executeDefaultOnClick: {
                    type: "boolean",
                    defaultValue: true
                }
            },
            events: {
                linkClick: {
                    enablePreventDefault: true,
                    parameters: {
                        semanticObject: {
                            type: "string"
                        },
                        semanticAttributes: {
                            type: "object"
                        },
                        semanticAttributesOfSemanticObjects: {
                            type: "object"
                        },
                        setSemanticAttributes: {
                            type: "function"
                        },
                        setAppStateKey: {
                            type: "function"
                        },
                        originalId: {
                            type: "string"
                        },
                        open: {
                            type: "function"
                        },
                        link: {
                            type: "object"
                        }
                    }
                }
            }
        },
        _onBeforePopoverOpens: function (e) {
            let bExecuteDefault = true;
            if (this.hasListeners("linkClick")) {
                const p = e.getParameters();
                if (this.getExecuteDefaultOnClick) {
                    bExecuteDefault = this._executeDefaultOnClick(p.semanticObject, p.semanticAttributes, e.getSource());
                }
                bExecuteDefault = this.fireEvent("linkClick", {
                    semanticObject: p.semanticObject,
                    semanticAttributes: p.semanticAttributes,
                    semanticAttributesOfSemanticObjects: p.semanticAttributesOfSemanticObjects,
                    setSemanticAttributes: p.setSemanticAttributes,
                    setAppStateKey: p.setAppStateKey,
                    originalId: p.originalId,
                    open: p.open,
                    link: e.getSource() //new one to get row
                }, true);
            }
            if (bExecuteDefault) {
                Control.prototype._onBeforePopoverOpens.apply(this, arguments);
            }
        },
        _executeDefaultOnClick: function (sSemanticObject, sSemanticAttributes, oLink) {
            if (sSemanticObject.indexOf("/MXP/DummyLink") < 0) {
                return false; // do not prevent default behavior
            }

            const sPost = sSemanticObject.substring(14);
            if (sPost.indexOf("TabQPPDType_") >= 0) {
                const sVart = sPost.substring(12);
                const sName = oLink.getText();
                library.openLink(this._getUrlForQPPD(sVart, sName), true);
            } else if (sPost.indexOf("PopoverQPPDType_") >= 0) {
                const sVart = oEvent.getParameter("semanticObject").substring(16);
                const sName = oSource.getText();
                tthis._getPopoverQPPD(sVart, sName).then((oPopover) => {
                    oPopover.openBy(oLink);
                    return oPopover;
                });
            } else {
                Log.error(`Unknown semantic object: ${sSemanticObject}`);
                return false; // do not prevent default behavior
            }

            return true; //prevent default behavior
        },
        _getPopoverQPPD: function (sVart, sName) {
            const oPopover = Fragment.load({
                id: "/MXP/PopoverQPPD",
                name: "com.metalsxp.vcha.uiextlib.fragment.PopoverIFrame",
                controller: {
                    onClose: function (oEvent) {
                        oPopover.close();
                        oPopover.destroy();
                    },
                }
            });
            oPopover.setTitle(this.getResourceBundle().getText("qppd"));
            oPopover.then((oPopover) => {
                oPopover.getContent()[0].setContent(`<iframe src='${this._getUrlForQPPD(sVart, sName)}' width='1000px' height='1000px' />`);
            });
            return oPopover;
        },
        _getUrlForQPPD: function (sVart, sName) {
            return `/fiori?#QPPD-displayFactSheet?Type=${sVart}&Name=${sName}`;
        }
    });
});