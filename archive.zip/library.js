/*!
 * ${copyright}
 */
sap.ui.define(["sap/ui/core/library"],function(){"use strict";sap.ui.getCore().initLibrary({name:"com.metalsxp.vcha.uiextlib",version:"1.0.0",dependencies:["sap.ui.core"],interfaces:[],controls:["com.metalsxp.vcha.uiextlib.SemanticObjectController"],elements:[],noLibraryCSS:true});var e=com.metalsxp.vcha.uiextlib;e.openLink=function(e,i){if(window.name.indexOf("itshtmlvwrfn")>=0){if(!i){document.location.href=e}else{window.top.open(e,i?"_blank":false)}}else{sap.m.URLHelper.redirect(e,i)}};return e});
//# sourceMappingURL=library.js.map